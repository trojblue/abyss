测试cloudflared:

```bash
cloudflared tunnel --url http://localhost:8888
jupyter-lab --allow-root	# 在另一个cmd里
```



登录cloudflared: 在能成功运行的jupyter lab里:

-  [使用Cloudflare Tunnel实现内网穿透，把服务器架在家里 (bra.live)](https://bra.live/setup-home-server-with-cloudflare-tunnel/)

```bash
cloudflared tunnel login  # 输入域名

cloudflared tunnel create webui #返回一个uuid
# > Created tunnel webui with id 349d7ccf-1a0f-4b64-a4c2-65ec29bfc608

# cloudflared tunnel route dns <隧道名字> <域名>
cloudflared tunnel route dns webui webui.noos.ca
# > INF Added CNAME webui.noos.ca which will route to this tunnel tunnelID=349d7ccf-1a0f-4b64-a4c2-65ec29bfc608
```



编辑配置文件:

```bash
nano ~/.cloudflared/config.yml
```

```yml
tunnel: 349d7ccf-1a0f-4b64-a4c2-65ec29bfc608
credentials-file: /root/.cloudflared/349d7ccf-1a0f-4b64-a4c2-65ec29bfc608.json
protocol: h2mux
originRequest:
  connectTimeout: 30s
  noTLSVerify: false
ingress:
  - hostname: webui.noos.ca
    service: https://localhost:7860

  - hostname: jupyter.noos.ca
    service: https://localhost:8888
    
  - service: http_status:404
```



install as service: [Run as a service on Linux · Cloudflare Zero Trust docs](https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/install-and-setup/tunnel-guide/local/as-a-service/linux/)



启动: [Run a tunnel · Cloudflare Zero Trust docs](https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/install-and-setup/tunnel-guide/local/run-tunnel/)

```bash
# cloudflared tunnel --config path/config.yaml run
cloudflared tunnel --config ~/vast_cloudflare.yml run
```
